const { app, BrowserWindow, ipcMain, screen, Tray, Menu, nativeImage, shell } = require('electron');
const path = require('path');
const fs = require('fs');

// ---- 설정값 ----
const NOTE_W = 380;          // 펼쳐졌을 때 메모 너비
const NOTE_H = 460;          // 펼쳐졌을 때 메모 높이
const SLIVER = 26;           // 평소(접힘) 화면에 보이는 색 띠 두께(px)
const TAB = 100;             // 접힘 탭의 길이(끝을 따라가는 방향) — 여러 메모가 나란히 보이게
const TWEEN_MS = 150;        // 펼침/접힘 슬라이드 시간
const COLORS = ['#FFE17A', '#FFB3BA', '#BAE1B3', '#B3D9FF', '#E0C3FF', '#FFD6A5', '#C9C9C9'];

// ---- 아이콘 / 저장 위치 ----
const ICON_ICO = path.join(__dirname, 'assets', 'cat-note.ico');   // Windows
const ICON_PNG = path.join(__dirname, 'assets', 'cat-note-512.png'); // macOS/공용
const ICON_PATH = process.platform === 'darwin' ? ICON_PNG : ICON_ICO;
const storePath = path.join(app.getPath('userData'), 'notes.json');

let notes = [];              // [{id,color,text,edge,offset}]
const wins = new Map();      // id -> BrowserWindow
const tweens = new Map();    // id -> interval handle
let tray = null;
let saveTimer = null;
let idSeq = 0;

// ---------- 저장 / 로드 ----------
function loadNotes() {
  try {
    notes = JSON.parse(fs.readFileSync(storePath, 'utf8').replace(/^﻿/, ''));
    if (!Array.isArray(notes)) notes = [];
  } catch {
    notes = [];
  }
  if (notes.length === 0) {
    notes.push(makeDefaultNote(0));
  }
}

function saveNotes() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.writeFileSync(storePath, JSON.stringify(notes, null, 2)); } catch (e) {}
  }, 300);
}

function makeDefaultNote(i) {
  return {
    id: 'n' + Date.now() + '_' + (idSeq++),
    color: COLORS[i % COLORS.length],
    text: '',
    edge: 'bottom',
    offset: 80 + i * (TAB + 14), // 끝을 따라가는 위치(상/하=왼쪽에서, 좌/우=위에서)
  };
}

// ---------- 창 위치 계산 ----------
// 접힘/펼침 각각의 bounds 를 edge 기준으로 산출
function noteW(note) { return note.w || NOTE_W; }
function noteH(note) { return note.h || NOTE_H; }

function boundsFor(note, expanded) {
  const wa = screen.getPrimaryDisplay().workArea; // 작업표시줄 제외 영역
  const edge = note.edge;
  const NW = noteW(note), NH = noteH(note);
  let x, y, w, h;

  if (edge === 'right' || edge === 'left') {
    w = NW;
    h = expanded ? NH : TAB;                      // 접히면 짧은 세로 탭
    y = clamp(wa.y + note.offset, wa.y, wa.y + wa.height - h);
    x = (edge === 'right')
      ? (expanded ? wa.x + wa.width - NW : wa.x + wa.width - SLIVER)
      : (expanded ? wa.x : wa.x - NW + SLIVER);
  } else { // top / bottom
    h = NH;
    w = expanded ? NW : TAB;                      // 접히면 짧은 가로 탭
    x = clamp(wa.x + note.offset, wa.x, wa.x + wa.width - w);
    y = (edge === 'top')
      ? (expanded ? wa.y : wa.y - NH + SLIVER)
      : (expanded ? wa.y + wa.height - NH : wa.y + wa.height - SLIVER);
  }
  return { x: Math.round(x), y: Math.round(y), width: Math.round(w), height: Math.round(h) };
}

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

// ---------- 슬라이드 애니메이션 ----------
function tweenTo(id, target) {
  const win = wins.get(id);
  if (!win || win.isDestroyed()) return;
  clearInterval(tweens.get(id));

  const start = win.getBounds();
  const t0 = Date.now();
  const handle = setInterval(() => {
    if (win.isDestroyed()) { clearInterval(handle); return; }
    const p = Math.min(1, (Date.now() - t0) / TWEEN_MS);
    const e = 1 - Math.pow(1 - p, 3); // easeOutCubic
    win.setBounds({
      x: Math.round(start.x + (target.x - start.x) * e),
      y: Math.round(start.y + (target.y - start.y) * e),
      width: Math.round(start.width + (target.width - start.width) * e),
      height: Math.round(start.height + (target.height - start.height) * e),
    });
    if (p >= 1) clearInterval(handle);
  }, 8);
  tweens.set(id, handle);
}

// ---------- 창 생성 ----------
function createNoteWindow(note, isNew) {
  const b = boundsFor(note, false);
  const win = new BrowserWindow({
    ...b,
    icon: ICON_PATH,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,         // 직접 OS 이동 끔(헤더 드래그로 우리가 제어)
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    focusable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.loadFile('renderer/index.html', { query: { id: note.id, new: isNew ? '1' : '' } });
  wins.set(note.id, win);

  win.on('closed', () => {
    wins.delete(note.id);
    clearInterval(tweens.get(note.id));
  });
  return win;
}

// ---------- 노트 헬퍼 ----------
function getNote(id) { return notes.find(n => n.id === id); }

function reposition(id, expanded) {
  const note = getNote(id);
  if (!note) return;
  tweenTo(id, boundsFor(note, expanded));
}

// 드래그 끝났을 때, 창 중심으로 가장 가까운 끝에 흡착
function snapToEdge(id, curBounds) {
  const note = getNote(id);
  if (!note) return;
  const wa = screen.getPrimaryDisplay().workArea;
  const cx = curBounds.x + curBounds.width / 2;
  const cy = curBounds.y + curBounds.height / 2;

  const dLeft = cx - wa.x;
  const dRight = (wa.x + wa.width) - cx;
  const dTop = cy - wa.y;
  const dBottom = (wa.y + wa.height) - cy;
  const min = Math.min(dLeft, dRight, dTop, dBottom);

  if (min === dRight || min === dLeft) {
    note.edge = (min === dRight) ? 'right' : 'left';
    note.offset = Math.round(clamp(curBounds.y - wa.y, 0, wa.height - TAB));
  } else {
    note.edge = (min === dBottom) ? 'bottom' : 'top';
    note.offset = Math.round(clamp(curBounds.x - wa.x, 0, wa.width - TAB));
  }
  saveNotes();
  const win = wins.get(id);
  if (win) win.webContents.send('edge-changed', note.edge);
  reposition(id, true); // 흡착 직후엔 펼친 상태로 정렬
}

// ---------- IPC ----------
ipcMain.handle('note:init', (e, id) => getNote(id));

ipcMain.on('note:expand', (e, id) => reposition(id, true));
ipcMain.on('note:collapse', (e, id) => reposition(id, false));

ipcMain.on('note:update', (e, { id, text, color }) => {
  const note = getNote(id);
  if (!note) return;
  if (typeof text === 'string') note.text = text;
  if (typeof color === 'string') note.color = color;
  saveNotes();
});

// 헤더 드래그: 렌더러가 마우스 이동 델타를 보냄
ipcMain.on('note:drag', (e, { id, dx, dy }) => {
  const win = wins.get(id);
  if (!win || win.isDestroyed()) return;
  clearInterval(tweens.get(id));
  const b = win.getBounds();
  win.setBounds({ x: Math.round(b.x + dx), y: Math.round(b.y + dy), width: b.width, height: b.height });
});

ipcMain.on('note:dragEnd', (e, id) => {
  const win = wins.get(id);
  if (!win || win.isDestroyed()) return;
  snapToEdge(id, win.getBounds());
});

ipcMain.on('note:new', () => addNote());
ipcMain.on('note:delete', (e, id) => deleteNote(id));

// 크기 조절: 렌더러가 원하는 펼침 너비/높이를 보냄 → 도킹 방향 유지하며 적용
ipcMain.on('note:resize', (e, { id, w, h }) => {
  const note = getNote(id);
  if (!note) return;
  const wa = screen.getPrimaryDisplay().workArea;
  note.w = Math.round(clamp(w, 220, wa.width));
  note.h = Math.round(clamp(h, 160, wa.height));
  saveNotes();
  const win = wins.get(id);
  if (win && !win.isDestroyed()) { clearInterval(tweens.get(id)); win.setBounds(boundsFor(note, true)); }
});

// 링크는 기본 브라우저로 열기
ipcMain.on('open-external', (e, url) => { try { shell.openExternal(url); } catch {} });

// ---------- 추가 / 삭제 ----------
function addNote() {
  const note = makeDefaultNote(notes.length);
  notes.push(note);
  saveNotes();
  createNoteWindow(note, true);
}

function deleteNote(id) {
  notes = notes.filter(n => n.id !== id);
  const win = wins.get(id);
  if (win && !win.isDestroyed()) win.close();
  if (notes.length === 0) addNote(); // 최소 1개 유지
  saveNotes();
}

// ---------- 트레이 ----------
function makeTrayIcon() {
  // 고양이 메모 아이콘을 트레이/메뉴바용으로 사용 (mac 은 png 가 안전)
  const src = process.platform === 'darwin' ? ICON_PNG : ICON_ICO;
  const img = nativeImage.createFromPath(src);
  return img.isEmpty() ? img : img.resize({ width: 18, height: 18 });
}

function setupTray() {
  tray = new Tray(makeTrayIcon());
  tray.setToolTip('엣지 포스트잇');
  const menu = Menu.buildFromTemplate([
    { label: '＋ 새 메모', click: () => addNote() },
    { label: '모두 펼치기', click: () => notes.forEach(n => reposition(n.id, true)) },
    { label: '모두 접기', click: () => notes.forEach(n => reposition(n.id, false)) },
    { type: 'separator' },
    { label: '종료', click: () => { app.isQuitting = true; app.quit(); } },
  ]);
  tray.setContextMenu(menu);
  tray.on('click', () => addNote());
}

// ---------- 앱 시작 ----------
app.whenReady().then(() => {
  app.setAppUserModelId('com.luna.edgepostit'); // 작업표시줄/알림 그룹 아이콘 식별자
  if (process.platform === 'darwin' && app.dock) {
    try { app.dock.setIcon(nativeImage.createFromPath(ICON_PNG)); } catch {}
  }
  loadNotes();
  notes.forEach(n => createNoteWindow(n));
  setupTray();
});

app.on('window-all-closed', (e) => {
  // 트레이로 상주 — 창 다 닫혀도 종료 안 함
  if (!app.isQuitting) { /* keep running */ }
});
