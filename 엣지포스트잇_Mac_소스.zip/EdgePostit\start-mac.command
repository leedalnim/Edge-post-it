#!/bin/bash
# 엣지 포스트잇 — macOS 실행 스크립트 (더블클릭)
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 가 필요합니다. https://nodejs.org 에서 LTS 버전을 먼저 설치해 주세요."
  echo "설치 후 이 파일을 다시 더블클릭하세요."
  read -n 1 -s -r -p "아무 키나 누르면 닫힙니다..."
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "처음 실행이라 필요한 구성요소를 설치합니다. (몇 분 걸릴 수 있어요)"
  npm install || { echo "설치 실패. 인터넷 연결을 확인하세요."; read -n 1 -s -r; exit 1; }
fi

echo "엣지 포스트잇 실행 중..."
npm start
