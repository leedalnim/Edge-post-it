// 고양이 메모지 아이콘(.ico) 생성기 — Electron 으로 SVG 렌더 → 멀티해상도 ICO
const { app, BrowserWindow, nativeImage } = require('electron');
const fs = require('fs');
const path = require('path');

const SVG = `
<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 256 256">
  <defs>
    <filter id="sh" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="6" stdDeviation="7" flood-color="#000000" flood-opacity="0.22"/>
    </filter>
  </defs>

  <!-- 메모지 본체 -->
  <g filter="url(#sh)">
    <rect x="34" y="34" width="188" height="188" rx="22" fill="#FFE17A"/>
    <!-- 접힌 모서리 -->
    <path d="M190 222 L222 222 L222 190 Z" fill="#F1C94B"/>
    <path d="M190 222 L222 190 L190 190 Z" fill="#FAD45F"/>
  </g>

  <!-- 고양이 발바닥 (육구) -->
  <g fill="#FF93A7" stroke="#E2728A" stroke-width="4" stroke-linejoin="round">
    <!-- 가운데 큰 패드 -->
    <path d="M128 188
             c-26 0 -42 -16 -42 -36
             c0 -20 19 -34 42 -34
             c23 0 42 14 42 34
             c0 20 -16 36 -42 36 Z"/>
    <!-- 발가락 콩 4개 -->
    <ellipse cx="82"  cy="118" rx="13" ry="17" transform="rotate(-18 82 118)"/>
    <ellipse cx="110" cy="98"  rx="13" ry="18" transform="rotate(-7 110 98)"/>
    <ellipse cx="146" cy="98"  rx="13" ry="18" transform="rotate(7 146 98)"/>
    <ellipse cx="174" cy="118" rx="13" ry="17" transform="rotate(18 174 118)"/>
  </g>
</svg>`;

const sizes = [256, 128, 64, 48, 32, 16];

function buildIco(pngs) {
  // pngs: [{size, buf}]
  const count = pngs.length;
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);      // reserved
  header.writeUInt16LE(1, 2);      // type = icon
  header.writeUInt16LE(count, 4);  // count

  const dir = Buffer.alloc(16 * count);
  let offset = 6 + 16 * count;
  const blobs = [];
  pngs.forEach((p, i) => {
    const b = i * 16;
    dir.writeUInt8(p.size >= 256 ? 0 : p.size, b + 0); // width
    dir.writeUInt8(p.size >= 256 ? 0 : p.size, b + 1); // height
    dir.writeUInt8(0, b + 2);   // colors
    dir.writeUInt8(0, b + 3);   // reserved
    dir.writeUInt16LE(1, b + 4);  // planes
    dir.writeUInt16LE(32, b + 6); // bitcount
    dir.writeUInt32LE(p.buf.length, b + 8);  // size in bytes
    dir.writeUInt32LE(offset, b + 12);       // offset
    offset += p.buf.length;
    blobs.push(p.buf);
  });
  return Buffer.concat([header, dir, ...blobs]);
}

app.whenReady().then(async () => {
  const R = 1024;
  const win = new BrowserWindow({
    width: R, height: R, show: false,
    transparent: true, frame: false,
    webPreferences: { offscreen: false },
  });
  await win.loadURL('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(SVG));
  await new Promise(r => setTimeout(r, 600));
  const full = await win.capturePage({ x: 0, y: 0, width: R, height: R });

  const pngs = sizes.map(s => ({
    size: s,
    buf: full.resize({ width: s, height: s, quality: 'best' }).toPNG(),
  }));

  const outDir = path.join(__dirname, 'assets');
  fs.mkdirSync(outDir, { recursive: true });
  // Windows 멀티해상도 .ico
  fs.writeFileSync(path.join(outDir, 'cat-note.ico'), buildIco(pngs));
  // PNG (미리보기 / macOS dock·빌드용)
  fs.writeFileSync(path.join(outDir, 'cat-note-1024.png'), full.toPNG());
  fs.writeFileSync(path.join(outDir, 'cat-note-512.png'), full.resize({ width: 512, height: 512, quality: 'best' }).toPNG());
  fs.writeFileSync(path.join(outDir, 'cat-note-256.png'), full.resize({ width: 256, height: 256, quality: 'best' }).toPNG());
  app.quit();
});
