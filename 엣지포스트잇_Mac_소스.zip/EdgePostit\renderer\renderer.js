const params = new URLSearchParams(location.search);
const ID = params.get('id');

const COLORS = ['#FFE17A', '#FFB3BA', '#BAE1B3', '#B3D9FF', '#E0C3FF', '#FFD6A5', '#C9C9C9'];

const noteEl = document.getElementById('note');
const ta = document.getElementById('ta');
const preview = document.getElementById('preview');
const colorbar = document.getElementById('colorbar');
const grab = document.getElementById('grab');
const resizeEl = document.getElementById('resize');

let expanded = false;
let dragging = false;
let resizing = false;
let editing = false;
let currentEdge = 'right';
let collapseTimer = null;

// 마크다운 설정
if (window.marked) {
  marked.setOptions({ gfm: true, breaks: true });
}

// ---------- 초기화 ----------
(async () => {
  const note = await window.postit.init(ID);
  if (!note) return;
  applyColor(note.color);
  ta.value = note.text || '';
  setEdgeClass(note.edge);
  buildPalette();
  renderPreview();
  if (params.get('new') === '1') {
    expand();
    setTimeout(enterEdit, 180);
  }
})();

function setEdgeClass(edge) {
  currentEdge = edge;
  noteEl.className = 'note edge-' + edge;
}
window.postit.onEdgeChanged(setEdgeClass);

function applyColor(c) { noteEl.style.setProperty('--c', c); }

function buildPalette() {
  colorbar.innerHTML = '';
  COLORS.forEach(c => {
    const d = document.createElement('div');
    d.className = 'dot';
    d.style.background = c;
    d.onclick = () => {
      applyColor(c);
      window.postit.update({ id: ID, color: c });
      colorbar.classList.add('hidden');
    };
    colorbar.appendChild(d);
  });
}

// ---------- 마크다운 보기 ----------
function renderPreview() {
  const md = ta.value || '';
  if (!md.trim()) {
    preview.classList.add('empty');
    preview.textContent = '클릭해서 메모 작성…';
    return;
  }
  preview.classList.remove('empty');
  preview.innerHTML = window.marked ? marked.parse(md) : md.replace(/\n/g, '<br>');

  // 체크박스: 클릭으로 토글 가능하게
  const boxes = preview.querySelectorAll('input[type="checkbox"]');
  boxes.forEach((box, i) => {
    box.disabled = false;
    const li = box.closest('li');
    if (li) li.classList.add('task');
    box.addEventListener('mousedown', (e) => e.stopPropagation());
    box.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleCheckbox(i);
    });
  });
  // 링크: 기본 브라우저로
  preview.querySelectorAll('a').forEach(a => {
    a.addEventListener('mousedown', (e) => e.stopPropagation());
    a.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      const href = a.getAttribute('href');
      if (href) window.postit.openExternal(href);
    });
  });
}

// n번째 할 일 항목의 [ ] <-> [x] 토글
function toggleCheckbox(index) {
  const lines = ta.value.split('\n');
  let count = -1;
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^(\s*[-*+]\s+)\[( |x|X)\]/);
    if (m) {
      count++;
      if (count === index) {
        const checked = m[2].toLowerCase() === 'x';
        lines[i] = lines[i].replace(/\[( |x|X)\]/, checked ? '[ ]' : '[x]');
        break;
      }
    }
  }
  ta.value = lines.join('\n');
  window.postit.update({ id: ID, text: ta.value });
  renderPreview();
}

// ---------- 편집 / 보기 전환 ----------
function enterEdit() {
  if (editing) return;
  editing = true;
  preview.classList.add('hidden');
  ta.classList.remove('hidden');
  ta.focus();
  const n = ta.value.length;
  try { ta.setSelectionRange(n, n); } catch {}
}
function exitEdit() {
  if (!editing) return;
  editing = false;
  ta.classList.add('hidden');
  renderPreview();
  preview.classList.remove('hidden');
}

// 보기 영역 클릭 → 편집 (링크/체크박스/리사이즈 제외는 위에서 stopPropagation)
preview.addEventListener('click', () => { expand(); enterEdit(); });

// ---------- 펼침 / 접힘 ----------
function expand() {
  clearTimeout(collapseTimer);
  if (expanded) return;
  expanded = true;
  window.postit.expand(ID);
}
function scheduleCollapse() {
  clearTimeout(collapseTimer);
  collapseTimer = setTimeout(() => {
    if (editing || !colorbar.classList.contains('hidden') || dragging || resizing) return;
    expanded = false;
    window.postit.collapse(ID);
  }, 350);
}

document.addEventListener('mouseenter', expand);
document.addEventListener('mouseover', expand);
document.addEventListener('mouseleave', scheduleCollapse);
ta.addEventListener('blur', () => { exitEdit(); scheduleCollapse(); });

// ---------- 텍스트 저장(디바운스) ----------
let saveT = null;
ta.addEventListener('input', () => {
  clearTimeout(saveT);
  saveT = setTimeout(() => window.postit.update({ id: ID, text: ta.value }), 250);
});

// ---------- 툴바 ----------
document.getElementById('add').onclick = () => window.postit.newNote();
document.getElementById('del').onclick = () => {
  if (confirm('이 메모를 삭제할까요?')) window.postit.deleteNote(ID);
};
document.getElementById('palette').onclick = () => colorbar.classList.toggle('hidden');

// ---------- 헤더 드래그 이동 ----------
const DRAG_THRESHOLD = 4;
let pressing = false, moved = false, lastX = 0, lastY = 0, downX = 0, downY = 0;

grab.addEventListener('mousedown', (e) => {
  if (e.target.closest('button')) return;
  pressing = true; moved = false;
  lastX = downX = e.screenX;
  lastY = downY = e.screenY;
  e.preventDefault();
});

// ---------- 크기 조절 ----------
let rs = null; // {startX, startY, startW, startH, edge}
resizeEl.addEventListener('mousedown', (e) => {
  e.preventDefault();
  e.stopPropagation();
  resizing = true;
  rs = {
    startX: e.screenX, startY: e.screenY,
    startW: window.innerWidth, startH: window.innerHeight,
    edge: currentEdge,
  };
});

window.addEventListener('mousemove', (e) => {
  // 이동
  if (pressing) {
    if (!moved && Math.abs(e.screenX - downX) + Math.abs(e.screenY - downY) < DRAG_THRESHOLD) return;
    moved = true; dragging = true;
    window.postit.drag({ id: ID, dx: e.screenX - lastX, dy: e.screenY - lastY });
    lastX = e.screenX; lastY = e.screenY;
    return;
  }
  // 크기 조절 — 도킹 방향에 따라 자유 모서리 기준으로 증감
  if (resizing && rs) {
    const dx = e.screenX - rs.startX;
    const dy = e.screenY - rs.startY;
    let w = rs.startW, h = rs.startH;
    if (rs.edge === 'right')  { w = rs.startW - dx; h = rs.startH + dy; }
    else if (rs.edge === 'left')   { w = rs.startW + dx; h = rs.startH + dy; }
    else if (rs.edge === 'bottom') { w = rs.startW + dx; h = rs.startH - dy; }
    else /* top */                 { w = rs.startW + dx; h = rs.startH + dy; }
    window.postit.resize({ id: ID, w, h });
  }
});

window.addEventListener('mouseup', () => {
  if (pressing) {
    pressing = false;
    if (moved) { dragging = false; window.postit.dragEnd(ID); }
  }
  if (resizing) { resizing = false; rs = null; }
});
