const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('postit', {
  init: (id) => ipcRenderer.invoke('note:init', id),
  expand: (id) => ipcRenderer.send('note:expand', id),
  collapse: (id) => ipcRenderer.send('note:collapse', id),
  update: (payload) => ipcRenderer.send('note:update', payload),
  drag: (payload) => ipcRenderer.send('note:drag', payload),
  dragEnd: (id) => ipcRenderer.send('note:dragEnd', id),
  newNote: () => ipcRenderer.send('note:new'),
  deleteNote: (id) => ipcRenderer.send('note:delete', id),
  resize: (payload) => ipcRenderer.send('note:resize', payload),
  openExternal: (url) => ipcRenderer.send('open-external', url),
  onEdgeChanged: (cb) => ipcRenderer.on('edge-changed', (e, edge) => cb(edge)),
});
